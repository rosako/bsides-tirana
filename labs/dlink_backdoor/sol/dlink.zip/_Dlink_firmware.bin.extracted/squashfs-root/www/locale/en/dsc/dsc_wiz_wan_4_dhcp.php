<h1>DHCP Connection (Dynamic IP Address)</h1>
<p>To set up this connection, please make sure that you are connected to the D-Link Router
using the PC that was originally connected to your broadband connection.
If you are, then click the Clone MAC Address button to copy your computer's MAC Address to the D-Link Router.</p>
