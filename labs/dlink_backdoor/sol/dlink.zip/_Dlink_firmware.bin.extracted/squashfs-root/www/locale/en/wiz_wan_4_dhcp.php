<?
$m_optional	= "(Optional)";
$m_clone_mac	= "Clone MAC Address";
$m_host_name	= "Host Name";
$m_host_name_note	= "Note: You may also need to provide a Host Name. If you do not have or know this information, please contact your ISP.";

$a_invalid_hostname     = "Invalid host name !";
$a_invalid_mac          = "Invalid MAC address !";
?>
