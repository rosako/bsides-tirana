<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."SYSTEM";
/* ---------------------------------------------------------------------- */
$a_empty_cfg_file_path		= "Please select a saved configuration file to upload.";
$a_sure_to_reload_cfg		= "Load Settings From File ?";
$a_sure_to_factory_reset	= "Restore To Factory Default Settings ?";
$a_sure_to_reboot			= "Reboot Router ?";
$a_sure_to_reset_js			= "Reset JumpStart ?";
$a_sure_to_clear_langpack	= "Clear the language pack ?";

$m_context_title	= "Save and Restore Settings";
$m_save_cfg			= "Save Settings To Local Hard Drive";
$m_load_cfg			= "Load Settings From Local Hard Drive";
$m_b_load			= "Upload Settings";
$m_factory_reset	= "Restore To Factory Default Settings";
$m_b_restore		= "Restore Device";
$m_b_reboot			= "Reboot";
$m_clear_langpack	= "Clear Language Pack";

$m_jumpstart_title	= "Jumpstart";
$m_enable_js_fn		= "Enable JumpStart function";
$m_reset_js			= "Reset JumpStart";
$m_apply			= "Apply";
$m_jumpstart		= "Jumpstart";
?>
