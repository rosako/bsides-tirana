<strong>Helpful Hints.</strong>
<br>
<br>
If the <strong>Measured Uplink Speed</strong> is known to be incorrect(that is, it produces suboptimal performance), disable <strong>Automatic Uplink Speed</strong> and enter the <strong>Manual Uplink Speed</strong>. Some experimentation and performance measurement may be required to converge on the optimal value.
