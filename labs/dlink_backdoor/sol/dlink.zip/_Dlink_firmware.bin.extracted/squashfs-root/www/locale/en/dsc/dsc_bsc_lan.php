<h1>Network Setting</h1>
<p>
Use this section to configure the internal network settings of your router and also to configure
 the built-in DHCP server to assign IP addresses to computers on your network. 
The IP address that is configured here is the IP address that you use to access the Web-based
 management interface. If you change the IP address in this section, you may need to adjust your PC's 
network settings to access the network again.
</p>
<p><b>
Please note that this section is optional and
you do not need to change any of the settings here
to get your network up and running.
</b></p>
