<h1>Internet Connection</h1>
If you are configuring the device for the first time,
we recommend that you click on the Internet Connection Setup Wizard button 
and follow the instructions on the screen.
If you wish to modify or configure the device settings manually,
click the Manual Internet Connection Setup button.
<br>
