<h1>Wireless Network</h1>
Use this section to configure the wireless settings for your D-Link router.
Please note that changes made in this section may also need to be duplicated
on your wireless client.
<p>
To protect your privacy you can configure wireless security features.
This device supports three wireless security modes including: WEP, WPA and WPA2.
<p>
