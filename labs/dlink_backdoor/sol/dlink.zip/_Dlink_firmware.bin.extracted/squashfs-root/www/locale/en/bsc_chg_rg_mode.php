<?
$m_title_chg_rg_mode = "Device Mode";
?>
