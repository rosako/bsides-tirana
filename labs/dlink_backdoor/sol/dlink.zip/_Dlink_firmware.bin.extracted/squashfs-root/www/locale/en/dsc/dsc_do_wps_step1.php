<h1>Add Wireless Device with WPS</h1>
<p>There are two ways to add wireless devices to your wireless network:
PIN number or Push Button.</p>
