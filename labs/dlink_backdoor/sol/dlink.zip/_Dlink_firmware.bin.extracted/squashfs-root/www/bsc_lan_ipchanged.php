<?
/* vi: set sw=4 ts=4: */
$MY_NAME	="bsc_lan_ipchanged";
$MY_MSG_FILE=$MY_NAME.".php";

$NO_NEED_AUTH="1";
require("/www/model/__html_head.php");
?>
<script>
function init()
{
}
</script>
<?
$REQUIRE_FILE="__msg_bsc_lan_ipchanged.php";
require("/www/model/__show_info.php");
?>
