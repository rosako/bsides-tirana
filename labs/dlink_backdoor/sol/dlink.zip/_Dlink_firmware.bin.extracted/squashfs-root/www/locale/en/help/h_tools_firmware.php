<strong>Helpful Hints..</strong>
<br><br>
&nbsp;&#149;&nbsp; <strong>Firmware Update</strong> are released periodically to improve the functionality
of your router and also to add features. If you run into a problem with a specific feature
of the router, check our support site by clicking on the
<strong>Click here to check for an upgrade on our support site</strong> and see if an
updated version of firmware is available for your router.
<br>
