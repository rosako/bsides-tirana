<?
$m_wel_set_wiz="WELCOME TO THE D-LINK EASY SETUP";
$m_connect_internet="Use easy setup will guide you through a step-by-step process to configure your new D-Link router.";
$m_easy_setup="Easy Setup ";
$m_manual_setup="Manual Setup ";
$m_always_easy="Always start up with easy setup <strong>after login</strong>.";
$m_cancel="Cancel";
?>
