<?
$m_system_uptime="System UpTime";
$m_days		= "days";
$m_expired	= "Expired";

$m_lan	= "LAN";
$m_netmask	= "Subnet Mask";
$m_dhcp_server	= "DHCP Server";

$m_wired= "Wired";
$m_wan	= "Internet";
$m_connection	= "Connection";
$m_default_gw	= "Default Gateway";
$m_dns		= "DNS";
$m_static_ip	= "Static IP";
$m_dhcp_client	= "DHCP client";
$m_connected	= "Connected";
$m_disconnected	= "Disconnected";
$m_connecting	= "Connecting...";
$m_disconnecting= "Disconnecting...";
$m_dhcp_renew	= "DHCP Renew";
$m_dhcp_release	= "DHCP Release";
$m_pppoe	= "PPPoE";
$m_russia_pptp          = "Russia PPTP (Dual Access)";
$m_russia_pppoe         = "Russia PPPoE (Dual Access)";
$m_russia_l2tp			= "Russia L2TP (Dual Access)";
$m_pptp		= "PPTP";
$m_l2tp		= "L2TP";
$m_connect	= "Connect";
$m_disconnect	= "Disconnect";
$m_na		= "N/A";
$m_null_ip	= "0.0.0.0";


$m_wlan	= "Wireless 802.11g";
$m_wlan_11n	= "Wireless 802.11n";
$m_ssid		= "SSID";
$m_channel	= "Channel";
$m_privacy	= "Encryption";
$m_wireless_jumpstart = "Wireless JumpStart";
$m_jumpstart	= "JumpStart";
$m_protocol	= "Protocol";
$m_status	= "Status";
$m_bits		= "bits";
$m_tkip		= "TKIP";
$m_aes		= "AES";
$m_cipher_auto	= "CIPHER_AUTO";

$m_test = "Verbindung wird getrennt (bitte warten...)";
?>
