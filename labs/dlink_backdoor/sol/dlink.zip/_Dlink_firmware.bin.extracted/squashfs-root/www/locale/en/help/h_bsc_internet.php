<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; If you are new to networking and have never configured a router before, click on <strong>Internet Connection Setup Wizard</strong> and the router will guide you through a few simple steps to get your network up and running.<br>
<br>
&nbsp;&#149;&nbsp; If you consider yourself an advanced user and have configured a router before, click<strong> Manual Internet Connection Setup</strong> to input all the settings manually.<br>

