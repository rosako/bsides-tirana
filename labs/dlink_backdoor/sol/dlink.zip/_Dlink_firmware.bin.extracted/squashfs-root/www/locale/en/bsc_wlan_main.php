<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."SETUP";
/* ---------------------------------------------------------------------- */
$m_title_wizard	= "Wireless Connection Setup Wizard";
$m_desc_wizard =
	"If you would like to utilize our easy to use Web-based Wizard to assist you ".
	"in connecting your new D-Link Systems Wireless Router to the Internet, click on the button below.";
$m_note_wizard =
	"<strong>Note:</strong> Before launching the wizard, ".
	"please make sure you have followed all steps outlined in the ".
	"Quick Installation Guide included in the package.";

$m_title_manual	= "Manual Wireless connection options";
$m_desc_manual =
	"If you would like to configure the Internet settings of your new ".
	"D-Link Router manually, then click on the button below.";

$m_setup_wiz	= "Wireless Connection Setup Wizard";
$m_manual_cfg	= "Manual Wireless Connection Setup";

?>
