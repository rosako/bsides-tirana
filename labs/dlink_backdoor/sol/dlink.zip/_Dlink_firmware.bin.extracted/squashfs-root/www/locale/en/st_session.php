<?
// -------------------------message start-------------------------
//$m_title="Active Sessions";
//$m_title_desc="Active Sessions displays the Source and Destination packets passing through the ".query("/sys/modelname").".";
$m_refresh="Refresh";
$m_refreshing="Refreshing ...";
$m_context_title_napt_session="NAPT Sessions";
$m_tcp_session="TCP Sessions";
$m_udp_session="UDP Sessions";
$m_total="Total";
$m_context_title_active_session="NAPT Active Sessions";
$m_ip_addr="IP Address";
$m_detail="detail";
// -------------------------message end--------------------------- */
?>
