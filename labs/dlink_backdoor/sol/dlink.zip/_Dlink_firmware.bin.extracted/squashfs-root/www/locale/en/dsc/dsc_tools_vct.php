<h1>System Check</h1>
The System Check tool can be used to verify the physical connectivity on
both the LAN and Internet interfaces. The Ping Test tool can be used to verify
the status of the Internet connection.
