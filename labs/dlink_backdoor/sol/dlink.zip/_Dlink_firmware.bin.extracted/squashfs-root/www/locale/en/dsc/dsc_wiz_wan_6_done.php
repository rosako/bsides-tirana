<h1 align="left">Rebooting...</h1>
<p>Saving Changes and Restarting.</p>
<p>If you changed the IP address of the router <br>
you will need to change the IP address in your <br>
browser before accessing the configuration Web site again.</p>
