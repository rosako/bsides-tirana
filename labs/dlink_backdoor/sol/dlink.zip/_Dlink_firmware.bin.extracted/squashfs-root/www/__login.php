<?
echo query("/runtime/auth/verification");
?>
