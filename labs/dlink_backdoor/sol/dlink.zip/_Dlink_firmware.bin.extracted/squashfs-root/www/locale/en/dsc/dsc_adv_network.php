<h1>Advanced Network Settings</h1>
<p>
These options are for users that wish to change the LAN settings.
We do not recommend changing these settings from factory default.
Changing these settings may affect the behavior of your network.
</p>
