<?
$m_title_vct_info	= "VCT INFO";
$m_title_ping_test	= "PING TEST";
$m_desc_ping_test	= "Ping Test is used to send &quot;Ping&quot; packets to test if a computer is on the Internet.";
$m_field_ping_test	= "Host Name or IP Address";
$m_ports		= "Ports";
$m_link_status		= "Link Status";
$m_title_ping_result	= "PING RESULT";
$m_wan			= "Internet";
$m_lan			= "LAN";
$m_disconnected		= "Disconnected";
$m_1000full		= "1000Mbps FULL Duplex";
$m_1000half		= "1000Mbps HALF Duplex";
$m_100full		= "100Mbps FULL Duplex";
$m_100half		= "100Mbps HALF Duplex";
$m_10full		= "10Mbps FULL Duplex";
$m_10half		= "10Mbps HALF Duplex";
$m_more_info		= "More Info";
$m_ping			= "Ping";
$m_ping_passed		= "Successful";
$m_ping_failed		= "Time out";

$m_refreshing		= "Refreshing ...";
$m_pinging		= "Pinging ...";

$a_empty_ip_addr	= "Please enter either a Host Name or an IP Address";
$a_invalid_ip_addr	= "Invalid Host Name or IP Address !";
?>
