<h1>Internet Usage Meter</h1>
Use this function to manage your Internet service.You can define what types of volume control you want to limit and notify users the current Internet used volume via web browser  or mail.This router also provides the Internet statistics so you can review your recent Internet usage.<br>
<br>
