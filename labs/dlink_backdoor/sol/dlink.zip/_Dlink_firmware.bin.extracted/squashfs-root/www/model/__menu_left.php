<table border="0" cellpadding="0" cellspacing="0">
<tr>
	<td id="sidenav_container">
		<div id="sidenav"><? require("/www/model/__menu_".$CATEGORY.".php"); ?></div>
		
	</td>
</tr>
</table>
