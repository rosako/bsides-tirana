<h1>Advanced Wireless settings</h1>
<p>
These options are for users that wish to change the behavior of their 802.11<?if(query("/runtime/func/ieee80211n")!="1"){ echo "g"; }else{ echo "n";} ?>
wireless radio from the standard settings. We do not recommend changing these
 settings from the factory defaults. Incorrect settings may impact the performance 
of your wireless radio. The default settings should provide the best
wireless radio performance in most environments.
</p>
