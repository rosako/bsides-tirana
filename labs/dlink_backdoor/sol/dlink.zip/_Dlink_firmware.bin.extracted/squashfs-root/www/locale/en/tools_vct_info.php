<?
/* vi: set sw=4 ts=4: */
$g_ww_cvt				= "./pic/wwvct.jpg";
$g_link					= "./pic/W_link.gif";
$g_nolink				= "./pic/W_nolink.gif";
$g_exit_p				= "./pic/exit_p.jpg";

$m_disconnected			= "Disconnected";
$m_100full				= "100Mbps FULL Duplex";
$m_100half				= "100Mbps HALF Duplex";
$m_10full				= "10Mbps FULL Duplex";
$m_10half				= "10Mbps HALF Duplex";
$m_1000full				= "1000Mbps FULL Duplex";
$m_1000half				= "1000Mbps HALF Duplex";
$m_error				= "Error";
$m_normal_cable			= "Normal Cable";
$m_open_cable			= "Open Cable";
$m_short_cable			= "Short Cable";
$m_wan					= "Internet";
$m_lan					= "LAN";
$m_txpair_normal_cable	= "TxPair Normal cable!";
$m_rxpair_normal_cable	= "RxPair Normal cable!";
$m_txpair_status		= "TxPair \"+getStatString(txstatus)+\"";
$m_rxpair_status		= "RxPair \"+getStatString(rxstatus)+\"";
$m_exit					= "Exit";
?>
