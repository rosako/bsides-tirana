<?
$m_wpa_dsc		="You have selected your wireless security level - you will need to set a wireless security password.";
$m_rule_guide	="The WPA (Wi-Fi Protected Access) key must meet one of following guidelines:";
$m_rule_1		=" - Between 8 to 63 characters (A longer WPA key is more secure than a short one)";
$m_rule_2		=" - Exactly 64 characters using 0-9 and A-F";
$m_wpa_key		="Network Key : ";
$m_note			="Note: You will need to enter the same password that you created in this step into your wireless clients in order to enable proper wireless communication.";
$a_invalid_secret   ="Invalid Network Key. Please enter another Network Key.";
?>
