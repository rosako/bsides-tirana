<?
$a_invalid_dest_ip	="Invalid Destination IP address.";
$a_invalid_netmask	="Invalid Subnet Mask.";
$a_invalid_gw		="Invalid Gateway.";
$a_same_rule		="There is a existing static routing rule with the same network address.\\n Please change it.";

$m_title_routing	="STATIC ROUTING";
$m_desc_routing		="ROUTING";
$m_inf				="Interface";
$m_dest				="Destination";
$m_submask			="Subnet Mask";
$m_gateway			="Gateway";
$m_wan_phy			="Physical Port";
$m_phy_prefix		="WAN Physical";
?>
