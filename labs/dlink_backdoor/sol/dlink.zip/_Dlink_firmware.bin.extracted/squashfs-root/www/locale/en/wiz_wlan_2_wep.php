<?
$m_wep_dsc		="You have selected your wireless security level - you will need to set a wireless security password.";
$m_rule_guide	="The WEP (Wired Equivalent Privacy) key must meet one of following guidelines:";
$m_rule_1		=" - Exactly 5 or 13 characters";
$m_rule_2		=" - Exactly 10 or 26 characters: using 0-9 and A-F";
$m_suggest		="A longer WEP key is more secure than a short one";
$m_wep_key		="Network Key : ";
$m_note			="Note: You will need to enter the same password that you created in this step into your wireless clients in order to enable proper wireless communication.";
$a_invalid_secret   ="Invalid Network Key. Please enter another Network Key.";
?>
