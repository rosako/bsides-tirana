<?
$a_invalid_hostname	="The Host Name is invalid.";
$a_invalid_username	="The User Name is invalid.";
$a_invalid_password	="The Password is invalid.";

$m_title_app_rules	="Dynamic DNS Settings";
$m_enable_ddns		="Enable DDNS";
$m_ddns_server		="Server Address";
$m_ddns_host_name	="Host Name";
$m_user				="Username";
$m_password			="Password";
$m_ddns_test		="DDNS Account Testing";
$m_testing       	="Testing";
$m_update_success	="Successfully updated";
$m_update_failed	="Failed to update";
?>
