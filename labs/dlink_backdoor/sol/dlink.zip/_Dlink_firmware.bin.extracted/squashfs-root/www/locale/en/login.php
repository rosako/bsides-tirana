<?
$a_invalid_user_name="Please input the User Name.";
$a_blank_vercode	="Please enter the graphical authentication code.";

$m_html_title		="LOGIN";
$m_context_title	="Login";
$m_login_router		="Log in to the router:";
$m_log_in			="Log In ";
$m_vercode			="Verification Code";
$m_wait_msg			="(Wait a moment ...)";
$m_gegenerate		="Regenerate";
$m_vercode_dsc		="Enter the correct password above and then type the characters you see in the picture below.";
?>
