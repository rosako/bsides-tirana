<table id=footer_container cellSpacing="0" cellPadding="5" width="838" align="center" border="0">
<tr>
	<td align=middle width=125>&nbsp;&nbsp;<img src="/pic/tail.gif" width="114" height="35"></td>
	<!--
	<td align=middle width=125>&nbsp;&nbsp;<img border=0 src="/pic/tail.gif" width="114" height="35"></td>
	-->
	<td width=10>&nbsp;</td>
	<td>&nbsp;</td>
</tr>
</table>
<?require("/www/model/__copyright.php");?>
