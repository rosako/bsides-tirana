<h1>Rebooting...</h1>
<center>
<br><br>
<p>Saving Changes and Restarting.</p>
<!--p>If you changed the IP address of the router <br>
 you will need to change the IP address in your <br>
  browser before accessing the configuration Web page again.</p-->
</center>
