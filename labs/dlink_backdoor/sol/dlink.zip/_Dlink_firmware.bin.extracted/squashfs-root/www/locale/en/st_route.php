<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."ROUTING";
/* ---------------------------------------------------------------------- */
$m_context_title_wlan	="&nbsp";
$m_dstip		="Destination IP";
$m_netmask		="Netmask";
$m_gateway		="Gateway";
$m_metric		="Metric";
$m_interface		="Interface";
$m_type			="Type";
$m_creator		="Creator";

$m_internet		="INTERNET";
$m_static		="STATIC";
$m_dhcpopt		="DHCP Option";
$m_admin                ="ADMIN";
$m_system		="System";
?>
