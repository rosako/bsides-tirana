<?
$m_title_log	= "Log Files";

$m_first_page	= "First Page";
$m_last_page	= "Last Page";
$m_previous	= "Previous";
$m_next		= "Next";
$m_clear	= "Clear";
$m_link_log_setting="Link To Log Settings";

$m_time		= "Time";
$m_message	= "Message";
$m_page		= "Page";
$m_of		= "of";
?>
