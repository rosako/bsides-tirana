<?
$m_wlan_ssid	="Wireless Network Name (SSID)";
$m_wep_length	="WEP Key Length";
$m_def_wep_index="Default WEP Key to Use";
$m_auth		="Authentication";
$m_key		="Network Key";
$m_encry	="Cipher Type";
$m_cipher	="TKIP or AES";
$m_secu		="Security Mode";
$m_psk		="Auto (WPA or WPA2) - Personal";
$m_128bits	="128 bits";
$m_64bits	="64 bits";

$m_open		="Open";

$m_note		="Note: In some smart wireless utilities (e.g. D-LINK wireless utility or wireless zero configuration), you only need to select a Wireless Network Name and enter a Network Key to access the Internet.";
?>
