<h1>SAVE AND RESTORE Settings</h1>
<p>
Once the router is configured you can save the configuration settings to a
configuration file on your hard drive. You also have the option to load
configuration settings, or restore the factory default settings.
</p>
