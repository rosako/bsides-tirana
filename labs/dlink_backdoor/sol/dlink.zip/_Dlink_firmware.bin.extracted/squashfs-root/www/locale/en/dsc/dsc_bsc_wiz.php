<h1>Wizard</h1>
The Wizard below will assist you in configuring the basic settings of your new D-Link Router.
<p>
