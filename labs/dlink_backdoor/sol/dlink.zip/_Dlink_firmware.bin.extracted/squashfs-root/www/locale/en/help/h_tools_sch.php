<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; Schedules are used with a number of other features to define when those features are in effect.<br><br>
&nbsp;&#149;&nbsp; Give each schedule a name that is meaningful to you. For example, a schedule for Monday through Friday from 3:00pm to 9:00pm, 
might be called &quot;After School&quot;.<br><br>
&nbsp;&#149;&nbsp; Click <strong>Save</strong> to add a completed schedule to the list below.<br><br>
&nbsp;&#149;&nbsp; Click <strong>Edit</strong> icon to change an existing schedule.<br><br>
&nbsp;&#149;&nbsp; Click <strong>Delete</strong> icon to permanently delete a schedule.
