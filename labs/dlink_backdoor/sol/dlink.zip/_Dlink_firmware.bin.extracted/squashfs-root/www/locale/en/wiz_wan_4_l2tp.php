<?
$m_address_mode	= "Address Mode";
$m_dynamic_ip	= "Dynamic IP";
$m_static_ip	= "Static IP";
$m_l2tp_ipaddr	= "L2TP IP Address";
$m_l2tp_netmask	= "L2TP Subnet Mask";
$m_l2tp_gateway	= "L2TP Gateway IP Address";
$m_l2tp_server	= "L2TP Server IP Address/Name<br>(may be same as gateway)";
$m_verify_pwd	= "Verify Password";

$a_invalid_ip           = "Invalid IP address !";
$a_invalid_netmask      = "Invalid subnet mask !";
$a_srv_in_different_subnet      = "Invalid server IP address! The server and router IP addresses should be in the same network.";
$a_gw_in_different_subnet       = "Invalid gateway IP address! The gateway and router IP addresses should be in the same network.";
$a_server_empty         = "Server IP/Name can not be empty !";
$a_account_empty        = "User Name can not be empty !";
$a_password_mismatch    = "The confirm password does not match the new password !";
$a_ip_equal_gateway		= "The IP address can not be equal to the gateway address!";
?>
