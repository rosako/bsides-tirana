<?
$m_title_qos = "QOS ENGINE SETUP";
$m_enable_autoQOS = "Enable QoS Engine";
$m_enable_autoBW = "Automatic Uplink Speed";
$m_uplinkspeed_auto = "Measured Uplink Speed";
$m_uplinkspeed_manual = "Manual Uplink Speed";
$m_nodetect = "Not Estimated";
$m_seltransrate = "Select Transmission Rate";
$m_conntype = "Connection Type";
$m_type_autodetect = "Auto-detect";
$m_type_adsl = "xDSL Or Other Frame Relay Network";
$m_type_cable = "Cable Or Other Broadband Network";
$m_adslorcable = "Detected xDSL or Other Frame Relay Network";
$a_invalid_bw = "Invalid Bandwidth Value !";
?>
