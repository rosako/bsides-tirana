<table cellSpacing="0" cellPadding="0" width=838 align="center" border="0">
<tr>
	<!--
	<td id="topnav_container_r"><img src="/pic/head_01.gif"></td>
	-->
	<td id="topnav_container_r"><a href="<? query("/sys/url"); ?>" target=_blank><img border=0 src="/pic/head_01.gif"></a></td>
	<td width="580" id="topnav_container_m" background="/pic/head_02.gif"></td>
	<td id="topnav_container_l"><img src="/pic/head_03.gif"></td>
</tr>
</table>
