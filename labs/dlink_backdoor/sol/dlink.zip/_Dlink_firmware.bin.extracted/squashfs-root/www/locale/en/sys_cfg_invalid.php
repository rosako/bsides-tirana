<?
$m_html_title="INVALID CONFIG FILE";
$m_context_title="Invalid Config File";
$m_context="The chosen file is not a valid config file.";
$m_button_dsc=$m_continue;
?>
