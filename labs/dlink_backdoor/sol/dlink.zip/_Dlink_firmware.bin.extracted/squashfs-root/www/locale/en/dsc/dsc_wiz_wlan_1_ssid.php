<h1>Step 1: SETUP YOUR WIRELESS NETWORK</h1>
<p>Give your network a name, using up to 32 characters.</p>
