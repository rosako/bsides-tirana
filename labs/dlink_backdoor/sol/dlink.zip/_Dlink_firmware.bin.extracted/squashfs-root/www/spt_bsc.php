<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="spt_bsc";
$MY_MSG_FILE	=$MY_NAME."php";
$SPT_FILE_NAME	=$MY_NAME;
$CATEGORY		="spt";
/* --------------------------------------------------------------------------- */
$NO_SESSION_TIMEOUT=1;
require("/www/model/__comm_spt.php");
?>
