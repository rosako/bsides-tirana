<h1 align="left">Welcome to the D-Link Wireless Security Setup Wizard</h1>
<p>This wizard will guide you through a step-by-step process to setup your wireless network and make it secure.</p>
<br>
<center>
<table>
<tr>
	<td>
		<UL>
		<LI>Step 1: Set your Wireless Network.
		<LI>Step 2: Set your Wireless Security Password
	</td>
</tr>
</table>
</center>
<br><br>
