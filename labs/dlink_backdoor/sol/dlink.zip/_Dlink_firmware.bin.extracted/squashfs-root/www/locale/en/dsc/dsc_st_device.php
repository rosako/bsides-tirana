<h1>Device Information</h1>
All of your Internet and network connection details are displayed on this page.
The firmware version is also displayed here.
<br>
