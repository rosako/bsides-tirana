
		<div class="box">
			<h2><?=$m_title_multicast_streams?></h2>
			<table cellSpacing=1 cellPadding=1 width=525 border=0>
			<tr>
				<td class="r_tb" width=160><?=$m_enable_multicast_streams?>&nbsp;:&nbsp;</td>
				<td class="l_tb">&nbsp;
					<input type="checkbox" name="multicast_streams" value=1 onclick="on_click_multicast_enable()">
				</td>
			</tr>
			<tr>
				<td class="r_tb" width=160><?=$m_enable_multicast_streams_enhancement?>&nbsp;:&nbsp;</td>
				<td class="l_tb">&nbsp;
					<input type="checkbox" name="multicast_enhancement" value=1>
				</td>
			</tr>
			</table>
		</div>
