<h1>MAC FILTERING</h1>
The MAC (Media Access Controller) Address filter option is used to
control network access based on the MAC Address of the network adapter.
A MAC address is a unique ID assigned by the manufacturer of the network adapter.
This feature can be configured to ALLOW or DENY network/Internet access.
<br><br>

