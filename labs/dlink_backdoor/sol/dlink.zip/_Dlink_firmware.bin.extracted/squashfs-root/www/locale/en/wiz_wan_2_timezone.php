<?
$m_time_zone	= "Time Zone";
$m_ntp_server	= "NTP Server Used";
$m_select_ntps	= "Select NTP Server";
$a_invalid_ntp_server   = "Invalid NTP server !";
?>
