<?
/* ---------------------------------------------------------------------- */
$a_empty_login_name		= "Please input the Login Name.";
$a_invalid_login_name	= "The Login Name is with invalid character. Please check it.";
$a_invalid_new_password	= "The New Password is with invalid character. Please check it.";
$a_password_not_matched	= "The New Password and Confirm Password are not matched.";
$a_invalid_ipaddr		= "Invalid IP Address.";

$m_context_title_admin	= "ADMIN PASSWORD";
$m_context_title_user	= "USER PASSWORD";
$m_enter_pwd_confirm_dec= "Please enter the same password into both boxes,for confirmation.";
$m_new_password			= "New Password";
$m_confirm_password		= "Confirm Password";

$m_context_title_remote	= "Administration";
$m_enable_grap_auth		= "Enable Graphical Authentication";
$m_eable_remote			= "Enable Remote Management";
$m_ip_allowed			= "IP Allowed to Access";
$m_defined_sch			= "Defined Schedule";
?>
