<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIRELESS";
/* ---------------------------------------------------------------------- */
$m_context_title_wlan	="NUMBER of WIRELESS CLIENTS : ";
$m_conn_time		="Connect Time";
$m_mode			="Mode";
$m_days			="days";
$m_hrs			="hours";
$m_mins			="minutes";
$m_secs			="seconds";
$m_rate			="Rate";
$m_signal		="Signal (%)";
?>
