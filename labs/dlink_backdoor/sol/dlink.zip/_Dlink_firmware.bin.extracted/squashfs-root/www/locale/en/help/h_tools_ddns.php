<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; To use this feature, you must first have a Dynamic DNS account from one of the providers in the drop down menu.