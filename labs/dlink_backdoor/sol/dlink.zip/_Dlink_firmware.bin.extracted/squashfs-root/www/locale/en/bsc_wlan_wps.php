<?
$m_title_wps	= "Wi-Fi Protected Setup (Also called WCN 2.0 in Windows Vista)";
$m_device_pin	= "Device PIN";
$m_wps_pin		= "WPS PIN";
$m_wps_button	= "WPS Button";
$m_gen_pin 		= "Generate New PIN";
$m_reset_pin	= "Reset PIN to Default";
$m_current_pin	= "Current PIN";
$m_wps_status	= "Wi-Fi Protected Status";
$m_configured	= "Configured";
$m_unconfigured	= "Not Configured";
$m_reset_wps 	= "Reset to Unconfigured";
$m_wps_wizard	= "Add Wireless Device with WPS";
?>
