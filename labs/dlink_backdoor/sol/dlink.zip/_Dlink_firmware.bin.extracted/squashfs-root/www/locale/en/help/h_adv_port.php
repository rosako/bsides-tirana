<strong>Helpful Hints..</strong>
<br><br>
&nbsp;&#149;&nbsp; Check the <strong>Application Name</strong> drop-down menu
for a list of pre-defined applications that you can select from. If you select
one of the pre-defined applications, click the arrow button next to the drop
-down menu to fill out the appropriate fields.
<br><br>
&nbsp;&#149;&nbsp; You can select your computer from the list of DHCP clients
 in the <strong>Computer Name</strong> drop-down menu, or enter the IP address 
manually of the computer you would like to open the specified port to.
<br><br>
&nbsp;&#149;&nbsp; This feature allows you to open a range of ports to a computer
on your network. To do so, enter the first port in the range you would like to
open on the router in the first box under <strong>Public Port</strong> and last
port of the range in the second one. After that you enter the first port in the
range that the internal server uses in the first box under <strong>Private Port</strong>
and the last port of the range in the second.
<br><br>
&nbsp;&#149;&nbsp; To open a single port using this feature, simply enter the same
number in both boxes. 
