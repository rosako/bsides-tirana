<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; 
All of your LAN, Internet and WIRELESS 802.11
<? if(query("/runtime/func/ieee80211n") != "1") { echo "G"; } else { echo "N"; }?>
 connection details are displayed here.
