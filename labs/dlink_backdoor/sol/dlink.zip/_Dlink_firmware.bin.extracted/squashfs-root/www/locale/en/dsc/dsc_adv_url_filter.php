<h1>Parental Control Rules </h1>
<p>
Parental Control are useful tools for restricting Internet access. The 
Website URL option allows you to quickly create a list of all web sites that you wish to allow
or deny users from accessing. The Schedule option allows you to control when clients
or PCs connected to the Router are allowed to access the Internet.
</p>
