<h1>Wireless Connection</h1>
<p>
There are 2 ways to setup your wireless connection.
You can use the Wireless Connection Setup Wizard or
you can manually configure the connection.
</p>
<p><b>
Please note that changes made in this section will also need to be duplicated on your wireless clients and PCs.
</b></p>
