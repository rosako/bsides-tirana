<h1>Add Wireless Device with WPS</h1>
<br><br>
<center><p>
You have failed to add the wireless device to your wireless network within the given time frame, please click on the button below to try again.
</p></center>
<br><br>
