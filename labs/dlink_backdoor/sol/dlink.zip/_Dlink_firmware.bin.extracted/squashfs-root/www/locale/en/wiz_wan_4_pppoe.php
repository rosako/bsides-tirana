<?
$m_address_mode	= "Address Mode";
$m_dynamic_ip	= "Dynamic IP";
$m_static_ip	= "Static IP";
$m_verify_pwd	= "Verify Password";
$m_service_name	= "Service Name";
$m_optional	= "(Optional)";
$m_service_name_note	= "Note: You may also need to provide a Service Name. If you do not have or know this information, please contact your ISP.";
$m_title_r_pppoe		= "WAN Physical Setting :";
$m_gateway				= "Gateway";
$m_subnet				= "Subnet Mask";
$m_dynamic_ip			= "Dynamic IP";
$m_static_ip			= "Static IP";
$m_primary_dns			= "Primary DNS Address";
$m_secondary_dns		= "Secondary DNS Address";


$a_invalid_username     = "Invalid user name !";
$a_password_mismatch    = "The confirm password does not match the new password !";
$a_invalid_ip           = "Invalid IP address !";
$a_invalid_netmask		= "Invalid subnet mask !";
$a_gw_in_different_subnet       = "Invalid gateway IP address ! The gateway and router addresses should be in the same network.";
$a_ip_equal_gateway		= "The IP address can not be equal to the gateway address!";
?>
