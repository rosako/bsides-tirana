<?
$a_quit_wiz			= "Quit Setup Wizard and discard changes?";
$a_sure_to_reboot	= "Reboot Router ?";

$m_pre_title	= "D-LINK SYSTEMS, INC | WIRELESS ROUTER | ";
$TITLE			= $m_pre_title."HOME";
$m_product_page	= "Product Page";
$m_hw_ver		= "Hardware Version";
$m_fw_ver		= "Firmware Version";
$m_wan_status	= "Internet Status";
$m_copyright	= "Copyright &copy; 2004-2010 D-Link Systems, Inc.";

$m_nochg_title	= "No Change";
$m_nochg_dsc	= "Settings have not changed.";
$m_saving_title	= "Saving";
$m_saving_dsc	= "The settings are being saved and are taking effect. <br><br> Please wait ...";
$m_remain_rules = "Remaining number of rules that can be created: ";

/* message for button.------------------------------------------*/
$m_back		= "Back";
$m_continue	= "Continue";
$m_logout	= "Logout";
$m_reboot	= "Reboot";
$m_apply	= "Apply";

$m_save_settings	= "Save Settings";
$m_no_save_settings	= "Don't Save Settings";

$m_add_new	= "New Schedule";
$m_prev		= "Prev";
$m_next		= "Next";
$m_cancel	= "Cancel";
$m_save		= "Save";
$m_connect	= "Connect";
$m_clear	= "Clear";

$m_connected	= "Connected";
$m_disconnected	= "Disconnected";
/* ------------------------------------------------------------*/
// week day and time
$m_sun	= "Sun";
$m_mon	= "Mon";
$m_tue	= "Tue";
$m_wed	= "Wed";
$m_thu	= "Thu";
$m_fri	= "Fri";
$m_sat	= "Sat";
$m_am	= "AM";
$m_pm	= "PM";

/* ------------------------------------------------------------*/
$m_name			= "Name";

$m_user_name	= "User Name";
$m_password		= "Password";

$m_ipaddr		= "IP Address";
$m_port			= "Port";
$m_schedule		= "Schedule";
$m_traffic_type	= "Traffic Type";
$m_macaddr		= "MAC Address";

$m_always		= "Always";
$m_never		= "Never";
$m_expired		= "Expired";

$m_auto			= "Auto";
$m_both			= "Both";
$m_none			= "None";

$m_disable		= "Disable";
$m_enable		= "Enable";

$m_disabled		= "Disabled";
$m_enabled		= "Enabled";

$m_edit			= "Edit";
$m_del			= "Delete";
?>
