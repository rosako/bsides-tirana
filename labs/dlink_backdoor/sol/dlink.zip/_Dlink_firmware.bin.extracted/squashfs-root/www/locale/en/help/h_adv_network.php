<strong>Helpful Hints..</strong>
<br><br>
&nbsp;&#149;&nbsp; For added security, it is recommended that you disable the <strong>WAN Ping Respond</strong>
option. Ping is often used by malicious Internet users to locate active networks or PCs.
<br><br>
&nbsp;&#149;&nbsp; If you are having trouble receiving video on demand type of service from the Internet, make sure the Multicast Stream option is enabled.
