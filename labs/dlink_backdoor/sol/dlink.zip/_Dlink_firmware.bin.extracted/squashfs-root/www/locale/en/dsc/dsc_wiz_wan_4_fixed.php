<h1>Set Static IP Address Connection</h1>
<p>To set up this connection you will need to have a complete list of all the 
IP information provided by your Internet Service Provider.
If you have a Static IP connection and do not have this information,
please contact your ISP.</p>
