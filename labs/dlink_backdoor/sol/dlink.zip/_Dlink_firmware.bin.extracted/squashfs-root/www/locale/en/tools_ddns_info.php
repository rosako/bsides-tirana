<?
$m_context_title= "DDNS Account Test";
$m_testing		="DDNS Account Testing...";
$m_test_timeout ="Test Timeout.";
$m_successful	="Update Successful.";
$m_fail			="Update Failed.";
$m_return_code	="Return Code";
?>
