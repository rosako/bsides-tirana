<h1>Setup Complete!</h1>
<p>The Setup Wizard has completed. Click the Connect button to save your settings and reboot the router.</p>
