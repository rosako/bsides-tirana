<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; This is a list of all wireless clients that are currently connected to your wireless router.