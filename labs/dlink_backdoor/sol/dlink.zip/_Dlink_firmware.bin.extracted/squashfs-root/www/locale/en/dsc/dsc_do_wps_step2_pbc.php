<h1>Virtual Push Button</h1>
<br><br>
<center><p>
Please press down the Push Button (physical or virtual) on the wireless device
you are adding to your wireless network within
<input type="Text" readonly name="WaitInfo" value="..." size="2"
style='border-width:0; background-color:#DFDFDF; color:#FF3030; text-align:center'>
seconds ...
</p></center>
<br><br>
