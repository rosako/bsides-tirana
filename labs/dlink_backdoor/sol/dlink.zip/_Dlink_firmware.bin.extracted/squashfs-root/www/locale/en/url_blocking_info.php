<?
$m_html_title="FORBIDDEN WEB ACCESS";
$m_context_title="Forbidden WEB Access";
$m_context="Access to this Web Site is not allowed from this computer. This page is not included in the router's Allowed Web Site List.";
?>
