<strong>Helpful Hints..</strong>
<br><br>
&nbsp;&#149;&nbsp; For security reasons, it is recommended that you change the Password 
for the Administrator account. Be sure to write down the new Passwords to avoid having to 
reset the router in the event that they are forgotten.
<br><br>
&nbsp;&#149;&nbsp; When enabling Remote Management, you can specify the IP address of the computer
on the Internet that you want to have access to your router, or leave it 0.0.0.0 to allow access to
any computer on the Internet.
<br>
