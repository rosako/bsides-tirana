<h1>Administrator Settings</h1>
<p>
The 'admin' account can access the management interface. The admin has read/write access and can change passwords.
By default there is no password configured. It is highly recommended that you create a password to keep your router secure.
</p>
