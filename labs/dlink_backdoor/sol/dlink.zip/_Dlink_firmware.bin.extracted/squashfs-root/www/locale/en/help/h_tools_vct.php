<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; &quot;Ping&quot; checks whether a computer on the Internet is running and responding. Enter either the IP address of the target computer or enter its fully 
qualified domain name. 