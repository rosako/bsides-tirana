<h1>Step 1: Set your Password</h1>
<p>By default, your new D-Link Router does not have a password configured for administrator access to the Web-based configuration pages.
To secure your new networking device, please set and verify a password below:</p>
