<h1>Dynamic DNS</h1>
The Dynamic DNS feature allows you to host a server (Web, FTP, Game Server, etc...) using a domain name that you have purchased (www.whateveryournameis.com) with your dynamically assigned IP address. Most broadband Internet Service Providers assign dynamic (changing) IP addresses. Using a DDNS service provider, your friends can enter your host name to connect to your game server no matter what your IP address is.
<br><br>
<div id="dsc_gen" style="display:none">
<a href="http://www.DLinkDDNS.com" target=_blank>Sign up for D-Link's Free DDNS service at www.DLinkDDNS.com.</a>
</div>
<p> 
