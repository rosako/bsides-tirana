<h1>Schedules</h1>
The Schedule configuration option is used to manage schedule rules for "MAC Filter",
"Firewall Rules" and "Parental Control".<br><br>
