<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."SCHEDULES";
/* ---------------------------------------------------------------------- */
$a_invalid_sch_name	="Please input a Name for the Schedule Rule.";
$a_invalid_days		="Please select day(s).";
$a_invalid_time		="Time is invalid.";
$a_invalid_start_time	="Invalid Start time. Start Time must be before End Time.";
$a_invalid_schedule	="Invalid Schedule Rule! Select All Week radio button and tick All Day - 24 hrs checkbox to create a Schedule Rule that runs all week and all day.";
$a_same_sch_as_always	="It's the same as schedule 'Always',are you going to continue?";
$a_del_confirm		="Are you sure that you want to delete this Schedule Rule?";
$a_same_name_record	="There is an existing Schedule Rule with the same Name.  \\n Please change the schedule Name.";
$a_same_time_record	="There is an exisitng Schedule Rule with the same Time Range.\\n  Please change the Time Range.";
$a_outside_max_rules	="Invalid Schedule. The maximum number of permitted Schedule rules has been exceeded.";


$m_add_sch_title="Add schedule rule";
$m_lst_sch_title="Schedule rules list";
$m_days		="Day(s)";
$m_all_week	="All Week";
$m_sel_days	="Select Day(s)";
$m_all_day	="All Day - 24 hrs";
$m_s_time	="Start Time";
$m_e_time	="End Time";
$m_time_dsc	="(hour:minute, 12 hour time)";
$m_time_frame	="Time Frame";
$m_to		="to";
?>
