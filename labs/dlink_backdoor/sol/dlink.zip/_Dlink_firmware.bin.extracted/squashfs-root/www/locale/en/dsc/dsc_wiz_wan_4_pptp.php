<h1>SET USERNAME AND PASSWORD CONNECTION (PPTP)</h1>
<p>To set up this connection you will need to have a Username and Password
 from your Internet Service Provider. You also need a PPTP IP address.
If you do not have this information, please contact your ISP.</p>
