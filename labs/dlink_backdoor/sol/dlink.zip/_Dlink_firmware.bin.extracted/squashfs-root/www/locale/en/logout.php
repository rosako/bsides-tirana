<?
$m_html_title="LOGOUT";
$m_context_title="Logout";
$m_context="You have successfully logged out.";
$m_button_dsc="Return to login page";
?>
