<?
/* vi: set sw=4 ts=4: */
$MY_NAME	="url_blocking_info";
$MY_MSG_FILE=$MY_NAME.".php";
$NO_NEED_AUTH       ="1";
$NO_SESSION_TIMEOUT ="1";
$NO_BUTTON          ="1";

require("/www/model/__html_head.php");
?>
<script>
function init()
{
}
</script>
<?
require("/www/model/__show_info.php");
?>
