<?
$m_context_title_stats	="&nbsp";
$m_receive		="Receive";
$m_transmit		="Transmit";
$m_wan			="Internet";
$m_lan			="LAN";
$m_wired		="WIRED";
if(query("/runtime/func/ieee80211n")==1){ $m_wlan_11g = "WIRELESS 11n";} else { $m_wlan_11g = "WIRELESS 11g"; }
$m_packets		="Packets";
$m_b_refresh		="Refresh";
$m_b_reset		="Reset";
$a_only_admin_account_can_clear_the_statistics="Only admin account can clear the statistics!";
?>
