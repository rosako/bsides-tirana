<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; Only enable the DMZ option as a last resort. If you are having trouble using an application from a computer behind the router, first try opening ports associated with the application in the Virtual Server or Port Forwarding sections.<br>
<br>
&nbsp;&#149;&nbsp; Make sure VPN passthrough is enabled if you are trying to use a VPN client from behind the router.<br>
<br>
&nbsp;&#149;&nbsp; VPN Passthrough will only function if the VPN client being used runs on the standards ports associated with the VPN connection type. If you are having problems getting your VPN client connected from behind the router and these VPN passthrough options are enabled, please contact your network administrator to find out if any non-standard ports or options are being used.<br>
