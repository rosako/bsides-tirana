#!/bin/sh
xmldbc -x /runtime/auth/verification "get:rndimage -p /usr/sbin/fonts -D"
