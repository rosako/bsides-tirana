<h1>View Log</h1>
The View Log displays the activities occurring on the <?query("/sys/modelname");?>.
