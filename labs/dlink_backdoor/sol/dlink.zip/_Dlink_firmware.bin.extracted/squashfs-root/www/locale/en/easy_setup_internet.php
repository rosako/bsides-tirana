<?
$m_config_connect="CONFIGURE YOUR INTERNET CONNECTION";
$m_internet_connection="Internet Connection";
$m_static_ip="Static IP";
$m_dhcp="Dynamic IP (DHCP)";
$m_pppoe="PPPoE";
$m_ip_addr="IP Address";
$m_sub_mask="Subnet Mask";
$m_gateway="Gateway Address";
$m_primary_dns="Primary DNS Server";
$m_second_dns="Secondary DNS Server";
$m_user_name="User Name";
$m_passwd="Password";
$m_confirm_passwd="Confirm Password";
$m_cancel="Cancel";

$a_invalid_ip       = "Invalid IP address !";
$a_invalid_netmask  = "Invalid subnet mask !";
$a_invalid_hostname = "Invalid host name !";
$a_invalid_username = "Invalid user name !";
$a_password_mismatch    = "The confirm password does not match the new password !";

$a_gw_in_different_subnet   = "Invalid gateway IP address ! The gateway and router addresses should be in the same network.";
$a_server_empty     = "Server IP/Name can not be empty !";
$a_account_empty    = "Account can not be empty !";
$a_ip_equal_gateway = "The IP address can not be equal to the gateway address!";

?>
