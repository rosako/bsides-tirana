<h1>Log SETTINGS</h1>
<p>Logs can be saved by sending it to an admin email address. </p>
