<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; This is a summary displaying the number of packets that have passed between the Internet and the LAN since the router was last initialized.
