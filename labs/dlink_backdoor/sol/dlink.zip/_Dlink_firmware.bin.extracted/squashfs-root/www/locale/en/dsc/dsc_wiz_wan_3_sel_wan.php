<h1>Step 3: Configure your Internet Connection</h1>
<br>
