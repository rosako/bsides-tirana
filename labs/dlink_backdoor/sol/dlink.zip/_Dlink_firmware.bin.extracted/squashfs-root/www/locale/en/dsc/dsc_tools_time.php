<h1>Time AND DATE</h1>
The Time and Date Configuration option allows you to configure, update,
and maintain the correct time on the internal system clock.
From this section you can set the time zone you are in
and set the NTP (Network Time Protocol) Server.
Daylight Saving can also be configured to adjust the time when needed
<br><br>
