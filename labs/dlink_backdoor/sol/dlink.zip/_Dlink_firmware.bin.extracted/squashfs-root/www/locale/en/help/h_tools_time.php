<strong>Helpful Hints..</strong><br>
<br>&nbsp;&#149;&nbsp;
Either enter the time manually by clicking the
<strong>Sync. Your Computers Time Settings</strong> button,
or use the <strong>Automatic Time Configuration</strong> option
to have your router synchronize with a time server on the Internet.<br>
