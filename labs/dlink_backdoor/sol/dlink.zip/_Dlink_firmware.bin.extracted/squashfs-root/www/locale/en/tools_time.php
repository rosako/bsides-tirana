<?
$m_title_time	= "Time and Date Configuration";
$m_time			= "Time";
$m_time_zone	= "Time Zone";
$m_enable_ds	= "Enable Daylight Saving";

$m_title_ntp	= "Automatic Time and Date Configuration";
$m_enable_ntp	= "Automatically synchronize with D-Link's Internet time server";
$m_interval		= "Interval";
$m_ntp_server	= "NTP Server Used";
$m_select_ntps	= "Select NTP Server";

$m_title_manual	= "Set the Time and Date Manually";
$m_year			= "Year";
$m_month		= "Month";
$m_day			= "Day";
$m_days			= "Days";
$m_hour			= "Hour";
$m_minute		= "Minute";
$m_second		= "Second";
$m_syncing		= "Synchronizing";
$m_synced		= "The time has been successfully synchronized.";
$m_next_sync	= "Next time synchronization";

$m_msync_msg	= "Sync. your computer's time settings";
$m_update_now	= "Update Now";

$a_invalid_ntp_server	= "Invalid NTP server !";
?>
