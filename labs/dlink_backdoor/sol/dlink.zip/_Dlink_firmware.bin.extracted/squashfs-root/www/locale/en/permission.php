<?
$m_context_title	="&nbsp";
$m_context		="Only the <strong>admin</strong> account can change the settings.";
$m_button_dsc		=$m_continue;
?>
