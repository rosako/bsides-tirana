<h1>Traffic Statistics</h1>
Traffic Statistics displays Receive and Transmit packets passing through the <?query("/sys/modelname");?>. <br>

