<?
/* set functions */
set("/function/httpd_upnp", "1");
set("/runtime/func/stun/enabled", "1");
set("/runtime/func/stun/type", "1");
?>
