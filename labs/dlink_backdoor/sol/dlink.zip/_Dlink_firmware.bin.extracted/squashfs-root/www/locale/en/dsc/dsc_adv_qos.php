<h1>QOS ENGINE</h1>
<p>
Use this section to configure D-Link's QoS Engine. The QoS Engine improves your online gaming experience by ensuring that your game traffic is prioritized over other network traffic, such as FTP or Web.
</p>
