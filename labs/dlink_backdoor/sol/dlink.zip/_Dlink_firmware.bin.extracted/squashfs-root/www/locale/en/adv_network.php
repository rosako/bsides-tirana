<?
$m_title_upnp			= "UPNP";
$m_title_wan_ping		= "WAN PING";
$m_title_wan_speed		= "WAN PORT SPEED";
$m_title_gaming_mode		= "GAMING MODE";
$m_title_multicast_streams	= "MULTICAST STREAMS";

$m_title_vpn_passthrough = "VPN PASSTHROUGH";
$m_desc_vpn =
	"Put text in here that says what the user should expect - like only 1 VPN ".
	"SW continually changes it may or maynot work.";
$m_enable_pptp_passthrough = "Enable PPTP Passthrough";
$m_enable_l2tp_passthrough = "Enable L2TP Passthrough";
$m_enable_ipsec_passthrough = "Enable IPSec Passthrough";

$m_desc_upnp		= "Universal Plug and Play (UPnP) supports peer-to-peer Plug and Play functionality for network devices.";
$m_desc_wan_ping	= "If you enable this feature, the WAN port of your router will respond to ping requests from the Internet that are sent to the WAN IP Address.";
$m_desc_gaming_mode	= "If you are having difficulties playing some online games - please enable this mode.";


$m_enable_upnp			= "Enable UPnP";
$m_enable_wan_ping		= "Enable WAN Ping Response";
$m_enable_gaming_mode		= "Enable GAMING mode";
$m_enable_multicast_streams	= "Enable Multicast Streams";
$m_enable_multicast_streams_enhancement	= "Wireless Enhance Mode";

$m_option_wan_speed_10		= "10Mbps";
$m_option_wan_speed_100		= "100Mbps";
$m_option_wan_speed_auto	= "10/100Mbps Auto";

?>
