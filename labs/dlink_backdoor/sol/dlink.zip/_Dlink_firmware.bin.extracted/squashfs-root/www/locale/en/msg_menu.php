<?
// category
$m_menu_top_bsc			= "Setup";
$m_menu_top_adv			= "Advanced";
$m_menu_top_tools		= "Maintenance";
$m_menu_top_st			= "Status";
$m_menu_top_spt			= "Help";

// basic
$m_menu_bsc_internet	= "Internet Setup";
$m_menu_bsc_wlan		= "Wireless Setup";
$m_menu_bsc_lan			= "LAN Setup";
$m_menu_adv_url_filter	= "Parental Control";

// easysetup
$m_menu_bsc_easysetup 	="Easy Setup";

// advanced
$m_menu_adv_vrtsrv		= "Virtual Server";
$m_menu_adv_port		= "Port Forwarding";
$m_menu_adv_app			= "Application Rules";
$m_menu_adv_mac_filter	= "MAC Filter";
$m_menu_adv_firewall	= "Firewall & DMZ";
$m_menu_adv_policy		= "Access Control";
$m_menu_adv_wlan		= "Advanced Wireless";
$m_menu_adv_network		= "Advanced Network";
$m_menu_adv_routing		= "Routing";
$m_menu_adv_qos			= "QoS Engine";

// tools
$m_menu_tools_admin		= "Device Administration";
$m_menu_tools_time		= "Time and Date";
$m_menu_tools_system	= "Save and Restore";
$m_menu_tools_firmware	= "Firmware Update";
$m_menu_tools_ddns		= "DDNS Setting";
$m_menu_tools_vct		= "System Check";
$m_menu_tools_sch		= "Schedules";
$m_menu_tools_log_setting="Log Settings";

// status
$m_menu_st_device		= "Device Info";
$m_menu_st_log			= "Log";
$m_menu_st_stats		= "Statistics";
$m_menu_st_session		= "Active Session";
$m_menu_st_wlan			= "Wireless";
$m_menu_st_route		= "Routing";

// support
$m_menu_spt_menu		= "Menu";
?>
