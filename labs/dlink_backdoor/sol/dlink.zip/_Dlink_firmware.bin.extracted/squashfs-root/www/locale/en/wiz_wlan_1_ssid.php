<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIZARD";
/* ---------------------------------------------------------------------- */
$a_empty_ssid	="The SSID field cannot be blank.";
$a_invalid_ssid	="There are some invalid characters in the SSID field. Please check it.";
$m_wlan_ssid	="Wireless Network Name (SSID)";
$m_auto_set		="Automatically assign a network key (Recommended)";
$m_auto_dsc		="To prevent intruders from accessing your network, the router will automatically assign a security key (also called WEP or WPA key) to your network.";
$m_manual_set	="Manually assign a network key";
$m_manual_dsc	="Use this option if you prefer to create your own key.";
$m_manual_wpa	="Use WPA encryption instead of WEP (WPA is stronger than WEP and all D-LINK wireless client adapters support WPA)";
?>
