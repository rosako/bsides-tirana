<?
$m_html_title="LAN IP Address Changed";
$m_context_title="LAN IP Address Changed";
?>
