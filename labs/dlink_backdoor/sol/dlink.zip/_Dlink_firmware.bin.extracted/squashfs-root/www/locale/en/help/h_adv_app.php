<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; Use the <strong>Application Name</strong> drop-down menu to view a list of pre-defined applications that you can select from. If you select one of the pre-defined applications, click the arrow button next to the drop-down menu to fill out the appropriate fields.<br>
