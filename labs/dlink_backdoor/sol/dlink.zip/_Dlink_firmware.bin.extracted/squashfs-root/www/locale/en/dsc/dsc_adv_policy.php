<h1>ACCESS CONTROL</h1>
<p>
The Access Control option allows you to control access in and out of your network. 
Use this feature as Access Controls to only grant access to approved sites, limit 
web access based on time or dates, and/or block internet access for applications 
like P2P utilities or games.
</p>
