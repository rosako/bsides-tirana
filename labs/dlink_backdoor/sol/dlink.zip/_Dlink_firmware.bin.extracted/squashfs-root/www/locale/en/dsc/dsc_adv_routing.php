<h1>Routing</h1>
The Routing option allows you to define static routes to specific destinations.
<p>
