<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; It is recommended that you leave these parameters with their default values. 
Adjusting them could limit the performance of your wireless network.<br><br>
&nbsp;&#149;&nbsp; Use <strong>802.11<? if(query("/runtime/func/ieee80211n") != "1") { echo "g"; } else { echo "n"; }?></strong> only for countries where it is required.<br>
