<?
$m_context_title="Napt Active Session Detail Information";
$m_active_session_lists="Napt Active Session Lists";
$m_protocol="Protocol";
$m_sip="Source IP";
$m_sport="Source Port";
$m_dip="Dest IP";
$m_dport="Dest Port";
$m_state="State";
$m_priority="Priority";
$m_timeout="Time Out";
$m_dir="Dir";
$m_dir_out="OUT";
$m_dir_in="IN";
?>
