<?
$m_mac_title	= "MAC FILTERING RULES";
$m_mac_desc	= "Configure MAC Filtering below:";

$m_mac_filter_off		= "Turn MAC Filtering OFF";
$m_mac_filter_allow_entries	= "Turn MAC Filtering ON and ALLOW computers listed to access the network";
$m_mac_filter_deny_entries	= "Turn MAC Filtering ON and DENY computers listed to access the network";

$m_dhcp_client_list	= "DHCP Client List";
$m_computer_name	= "Computer Name";
$m_clear		= "CLEAR";
$m_schedule		= "Schedule";
$m_always_on	= "Always On";

$a_no_pc_selected	= "Please select a machine first !";
$a_invalid_mac		= "Invalid MAC Address !";
$a_macaddr_exist	= "The MAC address already exists!";
$a_blocking_warning	= "The setting will block this machine from accessing the router!\\nAre you sure to continue ?";
?>
