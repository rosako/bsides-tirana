<h1>Advanced Port Forwarding Rules</h1>
The Advanced Port Forwarding option allows you to define a single public port on your
router for redirection to an internal LAN IP Address and Private LAN port if required.
This feature is useful for hosting online services such as FTP or Web Servers.
<p>
