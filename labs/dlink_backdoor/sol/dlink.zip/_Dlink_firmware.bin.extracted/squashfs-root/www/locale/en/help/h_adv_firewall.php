<strong>Helpful Hints..</strong>
<br><br>
&nbsp;&#149;&nbsp; <strong>DMZ:</strong><br>
Only enable the DMZ option as a last resort. If you are having trouble using 
an application from a computer behind the router, first try opening ports 
associated with the application in the Advanced Port Forwarding section.
<br><br>
&nbsp;&#149;&nbsp; <strong>Firewall:</strong><br>
Firewall Rules are an advanced feature used to deny or allow traffic from passing 
through the device. You can create detailed rules for the device.
Please refer to the manual for more details and examples.
<br>
