<?
$m_easy_setup_complete="Current Setting";
$m_click_button_to_save="This is the current setting of device.Click the <strong>Easy Setup</strong> or <strong>Manual Setup</strong> button to configure the device.";
$m_internet_setting="Internet Settings";
$m_internet_connection="Internet Connection";
$m_wireless_setting="Wireless Settings";
$m_wireless_name="Wireless Network Name (SSID)";
$m_secuity="Security";
$m_network_key="Network Key";
$m_static_ip = "Static IP";
$m_dhcp = "Dynamic IP (DHCP)";
$m_pppoe = "PPPoE";
$m_pptp = "PPTP";
$m_l2tp = "L2TP"; 
$m_save="Save";
$m_manual_setup="Manual Setup";
$m_easy_setup="Easy Setup";
$m_open="OPEN";
$m_share="Shared Key";
$m_wep="WEP";
$m_wpa_wpa2="Auto (WPA or WPA2) - Enterprise";
$m_wpa_wpa2_psk="Auto (WPA or WPA2) - Personal";
$m_disabled="Disabled";
?>

