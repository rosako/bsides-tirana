var result = <?

$RESULT = get("j", "/runtime/wps/result");

?>new Array("OK", "<?=$RESULT?>");
