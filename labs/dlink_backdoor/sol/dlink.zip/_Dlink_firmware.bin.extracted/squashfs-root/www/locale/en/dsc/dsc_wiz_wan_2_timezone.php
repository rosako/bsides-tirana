<h1>Step 2: Select your Time Zone</h1>
<p>Select the appropriate time zone for your location.
This information is required to configure the time-based options for the router.</p>
