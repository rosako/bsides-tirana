<h1>Active Session</h1>
Active Session displays Source and Destination packets passing through the <? echo query("/sys/modelname"); ?>.<br>

