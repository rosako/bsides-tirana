<?
$m_easy_setup_complete="EASY SETUP COMPLETE";
$m_click_button_to_save="The Easy Setup has completed.Click the Save button to save your settings and take effect.";
$m_internet_setting="Internet Settings";
$m_internet_connection="Internet Connection";
$m_wireless_setting="Wireless Settings";
$m_wireless_name="Wireless Network Name (SSID)";
$m_secuity="Security";
$m_network_key="Network Key";
$m_disabled="Disabled";
$m_wpa_wpa2="Auto (WPA or WPA2) - Personal";
$m_static_ip = "Static IP";
$m_dhcp = "Dynamic IP (DHCP)";
$m_pppoe = "PPPoE";
$m_save="Save";
$m_cancel="Cancel";
?>
