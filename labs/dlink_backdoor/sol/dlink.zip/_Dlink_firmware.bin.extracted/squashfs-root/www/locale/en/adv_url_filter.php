<?
$a_invalid_url       	= "Invalid URL !";
$a_same_url_entry_exists= "The URL/Domain entry already exists !";
$m_title_url_filter		= "Parental Control Rules";
$m_desc_url_filter		= "Configure Parental Control Rules below:";
$m_disable_url_filter	= "Turn Parental Control Rules OFF";
$m_allow_entries_only	= "Turn Parental Control Rules ON and ALLOW computers access to ONLY these sites";
$m_deny_entries_only	= "Turn Parental Control Rules ON and DENY computers access to ONLY these sites";
$m_clear_list_below		= "Clear the list below...";
$m_website_url			= "Website URL";
$m_schedule				= "Schedule";
?>
