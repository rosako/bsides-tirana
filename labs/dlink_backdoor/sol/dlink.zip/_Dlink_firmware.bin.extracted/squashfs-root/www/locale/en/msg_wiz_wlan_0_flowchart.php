<p align=left>This wizard will guide you through a step-by-step process to setup your wireless network and make it secure.</p>
<table class=formarea summary="wizard intro">
<tr>
	<td width="334" height="81">
	<ul>
	<li>Step 1: Name your Wireless Network
	<li>Step 2: Secure your Wireless Network
	<li>Step 3: Set your Wireless Security Password
	</ul></td>
</tr>
</table>
