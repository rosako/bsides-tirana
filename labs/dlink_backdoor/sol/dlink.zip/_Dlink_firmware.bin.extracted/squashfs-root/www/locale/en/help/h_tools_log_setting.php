<strong>Helpful Hints..</strong>
<br><br>
&nbsp;&#149;&nbsp; 
Click on the <strong>Save</strong> button to save log file to local hard drive which can later
send to the network administrator for troubleshooting. You can also select what type of event
you would like to be logged from <strong>Log Type & Level</strong>.
<br>
<br>
&nbsp;&#149;&nbsp; 
A System Logger (syslog) is a server that collects in one place the logs from different sources.
If the LAN includes a syslog server, you can use this option to send the router's logs to that server.
<br>
